DJI Mini 4 Pro — 3D 外观样例 v0.1

打开方式
1. Windows 运行 serve-preview.cmd（需要 Python 3），保持该窗口运行。
2. 浏览器打开 http://127.0.0.1:17839/ 。
3. 可拖动旋转、滚轮缩放，切换前/侧/俯/底视，以及开启桨叶旋转。
也可将 mini-4-pro.glb 直接导入支持 glTF 2.0 的查看器、Blender 或游戏引擎。

文件
- mini-4-pro.glb：独立三维模型，几何和材质全部内置，无外部贴图请求。
- model.js：可编辑的参数化网格源文件。?build=1 使用源文件构建而不是加载 GLB。
- index.html、vendor/：本地交互预览器及 Three.js 依赖。
- preview/：从导出后重新加载的 GLB 渲染的五个视角截图。
- verification.json、gltf-validation.json：网格统计与 Khronos glTF 校验结果。
- manifest.json：文件摘要、来源和交付范围。
- reference/：DJI 官方多视角外观参考图片。

模型说明
这是按官方产品图片和规格参考制作的外观近似重建，不是照片自动恢复出的真实 CAD，
不是原厂工程数据，也没有逐部件实测尺寸。底部和内部结构为简化表现。
模型使用米单位，Y 轴向上，+Z 为机头方向。展开姿态约 6.95 万三角面。
机身、机臂、云台、相机和四组桨叶为独立节点；Rotor_FL/FR/RL/RR 绕局部 Y 轴旋转。
桨叶动画由预览页驱动，GLB 本身没有烘焙动画。尚未做折叠机构、骨骼或物理碰撞体。
本轮只交付一款视觉试样，未修改或部署小程序、Android、鸿蒙和后端。

参考来源
https://www.dji.com/mini-4-pro/specs
https://store.dji.com/product/dji-mini-4-pro
https://repair.dji.com/help/content?customId=01700006559&lang=en&paperDocType=ARTICLE&re=US&spaceId=17
参考图片来自 DJI 官方 CDN，网址详见 manifest.json。
品牌及参考图片的权利属于各自权利人；此包不授予任何额外的品牌/原图商用许可。
本样例网格和建模代码在此次任务中本地创建，未调用付费模型生成服务。
Three.js 许可见 vendor/THREE-LICENSE.txt。
