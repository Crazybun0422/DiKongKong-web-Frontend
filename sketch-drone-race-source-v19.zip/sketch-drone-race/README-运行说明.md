# 涂鸦飞行社 · 源码运行说明

此包对应第 19 版，包含完整前后端源码、128 款机型定义、六条赛道、程序化黑洞、音乐音效、纹理、数据库迁移和资源生成脚本。
源码版本：74d713933ce428e9bc53a3eeded13e34cb062a04。

## 本次界面更新

- 机型库改为 3D 弧形轮播，支持点击、拖动、方向键切换和分类搜索。
- 精简机型卡片介绍与重复参数。
- 画布清空按钮换成 28px 橡皮擦图标，点击区域为 44×44px；点击清空整个画布。

## 本地启动

安装 Node.js 22.13.0 或更新的受支持版本，以及 pnpm 11.25.0。Windows 可在 PowerShell 或终端执行。以下命令在解压后的 sketch-drone-race 目录运行：

```sh
npm install -g pnpm@11.25.0
pnpm install --frozen-lockfile
pnpm dev
```

浏览器打开 http://localhost:5173 ，绘制或选择机型，点击“生成无人机”，即可单人试飞。
首次安装依赖需要网络；音乐与素材已包含在包内，不需要重新生成。

## 本地好友赛数据库

好友房间与比赛同步使用 Cloudflare D1；本地由开发工具模拟，不需要申请云端数据库即可调试。第一次使用好友赛，先停止开发服务，并执行：

```sh
pnpm build
pnpm exec wrangler d1 execute DB --config dist/server/wrangler.json --local --persist-to .wrangler/state --file drizzle/0000_sudden_hiroim.sql
pnpm dev
```

建表 SQL 在同一本地数据库上执行一次即可。生产部署时，将 DB 绑定至自己的 D1 数据库并应用同一迁移。这里只提供源码和建表结构，不含线上房间数据。

## 操作

| 操作 | 键盘 |
| --- | --- |
| 左右转向 | ← / → 或 A / D |
| 爬升、下降 | ↑ / ↓ 或 W / S |
| 冲刺 | 空格 |
| 减速 | 按住 Shift，松开恢复巡航 |
| 跟随 / 机载 FPV 视角 | V，或界面视角按钮 |

触屏界面提供转向、升降、减速和冲刺按钮。光环与障碍的位置固定；碰到实体障碍、光环框架或地面会坠毁。
六条赛道分别播放独立音乐；界面支持音乐、音效、语音音量调整。中文配音使用浏览器可用的中文语音。

## 目录

- app/drone-lab.tsx：画布、机库、比赛界面与输入控制。
- app/api/race/route.ts：好友房间、服务器比赛计算与同步。
- lib/airframes.ts、lib/sketch-shape.ts、lib/mesh.ts：机型、草图识别和机体建模。
- lib/drone.ts、lib/race-collision.ts、lib/courses.ts：飞行、碰撞、赛道规则。
- lib/race-camera.ts、lib/race-world.ts、lib/render.ts：FPV / 跟随镜头及两种绘制路径。
- lib/black-hole-fragment.ts、lib/black-hole.ts、public/black-hole-worker.js：程序化黑洞与兼容绘制。
- lib/game-audio.ts、public/audio/：音乐、音效和语音控制。
- public/textures/：纹理素材。
- db/、drizzle/：数据库结构和建表迁移。
- scripts/assets/：原创音乐与音效生成脚本及测量记录。

## 构建

```sh
pnpm build
pnpm start
```

构建结果在 dist/。本地生产服务地址以终端输出为准。

工程使用 React、TypeScript、Vinext/Vite、Canvas/WebGL 和 Cloudflare Workers/D1。草图识别是本地算法，没有接入外部生成式 AI 服务。

保留 .openai/hosting.json、build/ 和 scripts/：构建配置依赖这些文件。导出包没有 .sites-runtime 执行状态，启动时会自动使用普通本地开发模式。独立部署到新站点时，需要配置自己的站点与数据库绑定。

包内 README.md 保留早期迭代记录；当前运行方式、控制和版本信息以本文件及源码为准。

依赖安装目录、构建缓存、Git 历史、运行中的数据库与凭据不在压缩包内。本次修改已通过生产构建，压缩包已检查完整性；未在另一台机器上重新安装执行。
