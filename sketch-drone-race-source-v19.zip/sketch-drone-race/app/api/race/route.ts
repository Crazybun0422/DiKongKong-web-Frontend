import {MAX_SKETCH_POINTS,MAX_SKETCH_STROKES} from "@/lib/sketch-shape";
import {course,validCourse} from '@/lib/courses';
import {buildFromSketch,getAirframe} from "@/lib/airframes";
import {database} from "@/db/raw";
import {analyze,COLORS,Drone,Flight,initialFlight,stepFlight,Stroke} from "@/lib/drone";
export const dynamic="force-dynamic";
type RoomRow={code:string;host_id:string;status:string;start_at:number|null;created_at:number};
type PlayerRow={id:string;token:string;room_code:string;name:string;drone:string;state:string;steer:number;boost:number;updated_at:number;finish_ms:number|null};
class UserError extends Error{constructor(message:string,public status=400){super(message);}}
function cleanStrokes(value:unknown):Stroke[]{
 if(!Array.isArray(value)||value.length>MAX_SKETCH_STROKES||value.length<1)throw new UserError("请先画一架无人机。");let total=0;
 return value.map(s=>{if(!Array.isArray(s)||s.length<2||s.length>2000)throw new UserError("画稿格式不正确。");total+=s.length;if(total>MAX_SKETCH_POINTS)throw new UserError("画稿过于复杂，请减少笔画。");return s.map(p=>{if(!p||!Number.isFinite(p.x)||!Number.isFinite(p.y)||p.x<0||p.x>500||p.y<0||p.y>500)throw new UserError("画稿坐标不正确。");return {x:p.x,y:p.y};});});
}
async function snapshot(code:string){const db=database();const r=await db.prepare("SELECT * FROM race_rooms WHERE code = ?").bind(code).first<RoomRow>();if(!r)throw new UserError("房间不存在或已经关闭。",404);const now=Date.now();if(now-r.created_at>3600000)throw new UserError("房间已过期，请重新创建。",410);
 const rows=await db.prepare("SELECT * FROM race_players WHERE room_code = ? ORDER BY id").bind(code).all<PlayerRow>();
 const host=rows.results.find(p=>p.id===r.host_id);const courseId=course(host?JSON.parse(host.state).courseId:undefined).id;
 return {courseId,code:r.code,status:r.status,startAt:r.start_at,serverNow:now,players:rows.results.map(p=>({id:p.id,name:p.name,host:p.id===r.host_id,drone:JSON.parse(p.drone),state:JSON.parse(p.state),stateAt:p.updated_at,online:now-p.updated_at<8000,finishMs:p.finish_ms}))};
}
export async function POST(request:Request){try{
 const origin=request.headers.get("origin");if(origin&&new URL(origin).origin!==new URL(request.url).origin)throw new UserError("请求来源不匹配。",403);
 const raw=await request.text();if(raw.length>4000000)throw new UserError("画稿太大。",413);let p;try{p=JSON.parse(raw);}catch{throw new UserError("请求格式不正确。");}if(!p||typeof p!=="object")throw new UserError("请求格式不正确。");
 const db=database(),now=Date.now();let code=String(p.code||"").toUpperCase();
 if(p.action==="create"||p.action==="join"){
  const name=typeof p.name==="string"?p.name.trim().slice(0,16):"";if(!name)throw new UserError("请填写飞手昵称。");
  const strokes=cleanStrokes(p.strokes),color=COLORS.includes(p.color)?p.color:COLORS[0];let drone:Drone;try{if(p.catalogId!==undefined&&(typeof p.catalogId!=="string"||!getAirframe(p.catalogId)))throw new Error("机型不存在，请重新选择。");if(p.sketchMode!==undefined&&p.sketchMode!=="structure"&&p.sketchMode!=="silhouette")throw new Error("生成方式不正确。");drone=buildFromSketch(strokes,color,p.catalogId,p.sketchMode);}catch(e){throw new UserError((e as Error).message);}
  if(p.courseId!==undefined&&!validCourse(p.courseId))throw new UserError("赛场不存在，请重新选择。");let courseId=course(p.courseId).id;
  const id=crypto.randomUUID(),token=crypto.randomUUID()+crypto.randomUUID();
  if(p.action==="create"){
   const alphabet="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";code=Array.from(crypto.getRandomValues(new Uint8Array(6)),n=>alphabet[n%alphabet.length]).join("");
   await db.batch([db.prepare("INSERT INTO race_rooms (code, host_id, status, created_at) VALUES (?, ?, 'waiting', ?)").bind(code,id,now),db.prepare("INSERT INTO race_players (id, token, room_code, name, drone, state, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)").bind(id,token,code,name,JSON.stringify(drone),JSON.stringify(initialFlight(courseId)),now)]);
  }else{
   if(!/^[A-Z0-9]{6}$/.test(code))throw new UserError("请输入正确的 6 位房间码。");
   const room=await snapshot(code);courseId=room.courseId;if(room.status!=="waiting")throw new UserError("这个房间已经发车，请创建新房间。");
   const result=await db.prepare("INSERT INTO race_players (id, token, room_code, name, drone, state, updated_at) SELECT ?, ?, ?, ?, ?, ?, ? WHERE (SELECT COUNT(*) FROM race_players WHERE room_code = ?) < 6 AND (SELECT status FROM race_rooms WHERE code = ?) = 'waiting'").bind(id,token,code,name,JSON.stringify(drone),JSON.stringify(initialFlight(courseId)),now,code,code).run();if(!result.meta.changes)throw new UserError("房间已满或已经发车。");
  }return Response.json({session:{code,token,id},room:await snapshot(code)},{headers:{"Cache-Control":"no-store"}});
 }
 if(!/^[A-Z0-9]{6}$/.test(code)||typeof p.id!=="string"||typeof p.token!=="string")throw new UserError("房间身份无效，请重新加入。",401);
 const me=await db.prepare("SELECT * FROM race_players WHERE id = ? AND room_code = ? AND token = ?").bind(p.id,code,p.token).first<PlayerRow>();if(!me)throw new UserError("已离开房间，请重新加入。",401);
 const r=await db.prepare("SELECT * FROM race_rooms WHERE code = ?").bind(code).first<RoomRow>();if(!r||now-r.created_at>3600000)throw new UserError("房间已过期，请重新创建。",410);
 if(p.action==="leave"){
  if(r.host_id===me.id&&r.status==="waiting")await db.prepare("DELETE FROM race_rooms WHERE code = ?").bind(code).run();
  else if(r.status==="waiting")await db.prepare("DELETE FROM race_players WHERE id = ?").bind(me.id).run();
  else await db.prepare("UPDATE race_players SET updated_at = 0 WHERE id = ?").bind(me.id).run();
  return Response.json({ok:true});
 }
 if(p.action==="start"){
  if(r.host_id!==me.id)throw new UserError("只有房主可以发起比赛。",403);
  const count=await db.prepare("SELECT COUNT(*) AS n FROM race_players WHERE room_code = ? AND updated_at > ?").bind(code,now-8000).first<{n:number}>();if(!count||count.n<2)throw new UserError("需要至少两位在线飞手。");
  await db.prepare("UPDATE race_rooms SET status = 'racing', start_at = ? WHERE code = ? AND status = 'waiting'").bind(now+4000,code).run();
 }else if(p.action==="sync"){
  let state=JSON.parse(me.state) as Flight;let finish=me.finish_ms;
  if(r.status==="racing"&&r.start_at&&now>r.start_at&&!state.finished&&!state.crashed){
   const from=Math.max(me.updated_at,r.start_at),dt=Math.max(0,(now-from)/1000),drone=JSON.parse(me.drone) as Drone;
   state=stepFlight(state,drone,me.steer,!!me.boost,dt,state.liftInput??0,state.brakeInput===true);if(!state.crashed&&!state.finished)state.elapsed=(now-r.start_at)/1000;if(state.finished)finish=Math.round(state.elapsed*1000);
  }
  state.brakeInput=p.input?.brake===true;
  state.liftInput=p.input?.lift===1?1:p.input?.lift===-1?-1:0;
  const steer=p.input?.steer===-1?-1:p.input?.steer===1?1:0,boost=p.input?.boost===true?1:0;
  await db.prepare("UPDATE race_players SET state = ?, steer = ?, boost = ?, updated_at = ?, finish_ms = ? WHERE id = ? AND updated_at = ?").bind(JSON.stringify(state),steer,boost,now,finish,me.id,me.updated_at).run();
 }else throw new UserError("未知操作。");
 return Response.json({room:await snapshot(code)},{headers:{"Cache-Control":"no-store"}});
 }catch(e){if(e instanceof UserError)return Response.json({error:e.message},{status:e.status});console.error("race request failed",e);return Response.json({error:"比赛服务暂时不可用，你的画稿仍在。请稍后重试。"},{status:503});}}
