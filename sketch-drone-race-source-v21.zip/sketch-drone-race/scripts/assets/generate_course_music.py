"""Six original course-specific race scores. Pure offline synthesis.
No source recordings, samples, external songs, voices, or audio APIs.
Every score has its own harmony, hook, bass rhythm, groove and timbral design.
All events and effects wrap into a sample-exact sixteen-bar buffer.
"""
from pathlib import Path
import json, subprocess, sys
import numpy as np
from scipy.signal import butter, sosfilt, resample_poly
from scipy.io import wavfile

OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[2]/'public'/'audio'
OUT.mkdir(parents=True,exist_ok=True)
SR=48000; BARS=16; TARGET_RMS=-15.3
CONFIGS=[
 dict(id='valley',name='翡翠山谷',title='Ridge Runner',bpm=132,key='D major',style='Lively melodic electro; springy offbeat bass and a rising pentatonic hook',
      chords=[[50,54,57,64],[47,50,54,57],[43,47,50,57],[45,49,52,59]],roots=[38,35,31,33],
      progression='Dadd9 – Bm7 – Gadd9 – Aadd9', arp=[0,2,1,3,2,0,3,1],
      motif=[[74,78,81,78,76],[74,73,69,71,74],[71,74,78,74,71],[73,76,81,76,73]],
      rhythm=[0,.75,1.5,2.5,3.25],bass=[(0,0),(.75,0),(1.5,12),(2,0),(2.75,7),(3.5,0)],kind='pluck'),
 dict(id='canyon',name='赤岩峡谷',title='Redstone Drive',bpm=138,key='D minor / Phrygian color',style='Percussive broken electro; 3+3+2 bass accents, hand-tom syncopation, low modal riff',
      chords=[[50,53,57,60],[51,55,58,62],[48,52,55,58],[50,53,57,62]],roots=[38,39,36,38],
      progression='Dm7 – Ebmaj7 – C7 – Dm',arp=[0,0,2,1,0,3,2,0],
      motif=[[62,65,63,62],[63,67,65,63],[60,64,67,64],[62,65,69,62]],
      rhythm=[0,.75,2,2.75],bass=[(0,0),(.75,0),(1.5,7),(2,0),(2.75,12),(3.25,7),(3.75,0)],kind='wood'),
 dict(id='coast',name='蔚蓝海岸',title='Sunlit Wake',bpm=128,key='F major',style='Bright coastal house; syncopated chord chops, bouncy octave bass and an answering mallet melody',
      chords=[[53,57,60,67],[55,58,62,65],[58,62,65,69],[60,64,67,70]],roots=[29,31,34,36],
      progression='Fadd9 – Gm7 – Bbmaj7 – C7',arp=[2,1,3,2,0,2,1,3],
      motif=[[77,79,81,84,81,79],[79,82,81,77,79,74],[77,81,82,86,84,81],[79,76,79,82,84,79]],
      rhythm=[.5,1,1.75,2.5,3,3.5],bass=[(0,0),(.5,12),(1.5,0),(2.25,7),(2.75,12),(3.5,0)],kind='mallet'),
 dict(id='snow',name='极光雪岭',title='Aurora Ascent',bpm=124,key='B minor',style='Airy progressive breaks; interlaced crystal arpeggios, suspended voicings and broad half-time snare',
      chords=[[47,50,54,61],[45,49,52,59],[43,47,50,57],[42,47,49,54]],roots=[35,33,31,30],
      progression='Bmadd9 – Aadd9 – Gadd9 – F#sus4',arp=[0,2,3,1,2,0,1,3,2,1,3,0,1,2,0,3],
      motif=[[78,81,85],[76,73,71],[74,78,81],[73,71,66]],
      rhythm=[.5,2,3.25],bass=[(0,0),(1.5,7),(2.75,0),(3.5,12)],kind='glass'),
 dict(id='city',name='霓虹夜城',title='Neon Slipstream',bpm=112,key='F# minor',style='Driving synthwave; straight eighth-note motor bass, warm analog chords and a long singing lead',
      chords=[[54,57,61,64],[50,54,57,61],[52,56,59,64],[49,54,56,61]],roots=[30,26,28,25],
      progression='F#m7 – Dmaj7 – E – C#sus4',arp=[0,2,1,2,3,2,1,2],
      motif=[[73,76,80,78],[78,76,73,69],[71,76,80,76],[73,68,71,73]],
      rhythm=[0,1.5,2.5,3.5],bass=[(0,0),(.5,0),(1,12),(1.5,0),(2,0),(2.5,0),(3,7),(3.5,12)],kind='analog'),
 dict(id='alien',name='黑洞荒原',title='Event Horizon Pulse',bpm=136,key='C minor',style='Dark space techno; asymmetric pulse ostinato, low dissonant textures and a sparse descending signal motif',
      chords=[[48,51,55,62],[44,48,51,55],[41,48,53,56],[43,47,50,56]],roots=[36,32,29,31],
      progression='Cmadd9 – Abmaj7 – Fm – G(b9)',arp=[0,1,0,3,0,2,1,0],
      motif=[[75,74,72],[75,72,67],[77,72,68],[74,71,68]],
      rhythm=[.25,1.75,3],bass=[(0,0),(.75,0),(1.5,12),(2.5,0),(3.25,7)],kind='dark')
]

def hz(note): return 440*2**((note-69)/12)
def low(x,f=4500): return sosfilt(butter(2,f,fs=SR,output='sos'),x,axis=0)
def high(x,f=5000): return sosfilt(butter(2,f,'highpass',fs=SR,output='sos'),x,axis=0)
def envelope(t,att=.004,dec=.2,tail=.03):
    return (1-np.exp(-t/att))*np.exp(-t/dec)*np.minimum(1,np.maximum(0,(t[-1]-t)/tail))
def voice(note,dur,kind,vel=1):
    t=np.arange(round(dur*SR))/SR; f=hz(note); p=2*np.pi*f*t
    if kind=='pad':
        a=np.minimum(1,t/.19)*np.minimum(1,np.maximum(0,(dur-t)/.4))
        x=np.column_stack([np.sin(p*.998)+.26*np.sin(p*2*.998)+.1*np.sin(p*3*.998),np.sin(p*1.002)+.26*np.sin(p*2*1.002)+.1*np.sin(p*3*1.002)])
        return x*(a*vel)[:,None]
    if kind=='bass':
        x=np.sin(p)+.24*np.sin(2*p)+.09*np.sin(3*p)
        return x*envelope(t,.003,.3,.025)*vel
    if kind=='motor':
        x=np.sin(p)+.34*np.sin(2*p)+.17*np.sin(3*p)+.07*np.sin(5*p)
        return np.tanh(x)*envelope(t,.003,.27,.024)*vel
    if kind=='wood':
        x=np.sin(p+1.15*np.sin(p*1.501)*np.exp(-t/.038))+.22*np.sin(2*p)
        return np.tanh(x*1.3)*envelope(t,.002,.15,.03)*vel
    if kind=='glass':
        x=np.sin(p+.58*np.sin(p*2.002)*np.exp(-t/.31))+.07*np.sin(p*3.997)*np.exp(-t/.15)
        return x*envelope(t,.006,.36,.06)*vel
    if kind=='mallet':
        x=np.sin(p+.35*np.sin(p*3)*np.exp(-t/.026))+.14*np.sin(p*2)*np.exp(-t/.09)
        return x*envelope(t,.002,.17,.04)*vel
    if kind=='analog':
        x=sum(np.sin(p*h)/h**1.55 for h in range(1,8))
        x+=.22*np.sin(p*1.003)
        return x*envelope(t,.018,.48,.075)*vel
    if kind=='dark':
        x=np.sin(p+.46*np.sin(p*.501)*np.exp(-t/.12))+.21*np.sin(2*p)+.06*np.sin(4*p)
        return x*envelope(t,.004,.18,.04)*vel
    x=np.sin(p)+.24*np.sin(2*p)*np.exp(-t/.1)+.12*np.sin(3*p)*np.exp(-t/.07)
    return x*envelope(t,.004,.21,.04)*vel

def drums(rng,id):
    t=np.arange(round(.43*SR))/SR
    fundamental={'valley':53,'canyon':49,'coast':57,'snow':50,'city':47,'alien':44}[id]
    f=fundamental+108*np.exp(-t/.014)+18*np.exp(-t/.052)
    k=np.sin(2*np.pi*np.cumsum(f)/SR)*envelope(t,.0007,.11,.025)
    k+=low(rng.standard_normal(len(t)),2800)*np.exp(-t/.004)*.06
    t=np.arange(round(.25*SR))/SR
    noise=low(high(rng.standard_normal(len(t)),900),6000)
    s=(noise*.47+np.sin(2*np.pi*185*t)*.22)*envelope(t,.0007,.055,.02)
    if id=='city':
        for d in [int(.014*SR),int(.027*SR)]: s[d:]+=noise[:-d]*np.exp(-t[:-d]/.047)*.18
    t=np.arange(round(.09*SR))/SR
    h=low(high(rng.standard_normal(len(t)),6200),11000)*envelope(t,.0006,.022,.017)*.22
    t=np.arange(round(.23*SR))/SR
    oh=low(high(rng.standard_normal(len(t)),5700),10000)*envelope(t,.001,.069,.03)*.20
    t=np.arange(round(.22*SR))/SR
    f=125+45*np.exp(-t/.018)
    tom=(np.sin(2*np.pi*np.cumsum(f)/SR)+low(rng.standard_normal(len(t)),1500)*.25)*envelope(t,.001,.061,.027)*.43
    return k,s,h,oh,tom

def circular_filter(x,hz):
    # Prime the IIR from the previous end to keep filter state continuous at wrap.
    pre=round(SR*.12)
    extended=np.concatenate([x[-pre:],x],axis=0)
    return low(extended,hz)[pre:]

def render(c):
    id=c['id']; rng=np.random.default_rng(4027+sum(map(ord,id)))
    n=round(BARS*4*60/c['bpm']*SR); beat=n/(SR*BARS*4)
    layer={a:np.zeros((n,2),np.float32) for a in ['drums','bass','arp','pad','lead','texture']}
    def add(dst,x,beats,pan=0,gain=1):
        j=round(beats*beat*SR); index=(j+np.arange(len(x)))%n
        if x.ndim==1:
            p=(pan+1)*np.pi/4
            dst[index,0]+=x*(np.cos(p)*gain);dst[index,1]+=x*(np.sin(p)*gain)
        else: dst[index]+=x*gain
    k,s,h,oh,tom=drums(rng,id)
    for bar in range(BARS):
        base=bar*4; ci=(bar//2)%4; ch=c['chords'][ci]; root=c['roots'][ci]
        alt=bar>=8
        # Each course has a different kick/snare foundation.
        kicks={'valley':[0,1,2,3],'canyon':[0,.75,2,2.75,3.5], 'coast':[0,1,2,3],
               'snow':[0,1.5,2.75,3.5], 'city':[0,1,2,3], 'alien':[0,1,2,3]}[id]
        for off in kicks: add(layer['drums'],k,base+off,gain=.76)
        snares=[2] if id in ['snow','alien'] else [1,3]
        for off in snares: add(layer['drums'],s,base+off+.009,gain=.58 if id!='snow' else .79,pan=.035)
        # Soft ghost snares drive the broken patterns without sounding busy.
        if id in ['snow','canyon']:
            add(layer['drums'],s,base+3.25,gain=.14,pan=-.16)
        for st in range(8):
            swing=.037 if id=='coast' and st%2 else 0
            add(layer['drums'],h,base+st*.5+swing,pan=(-.26 if st%2==0 else .24),gain=.5 if st%2==0 else .83)
            if st%2 and id not in ['snow','canyon']:
                add(layer['drums'],oh,base+st*.5,pan=.28,gain=.29 if id!='alien' else .2)
        if alt or id in ['canyon','snow']:
            for st in ([3,7,11,15] if id!='alien' else [3,6,11,14]):
                add(layer['drums'],h,base+st*.25,pan=-.35,gain=.25)
        if id=='canyon':
            for off,v in [(.5,.34),(1.25,.25),(2.5,.35),(3.25,.23)]: add(layer['drums'],tom,base+off,pan=(-.32 if off<2 else .27),gain=v)
        if id=='coast':
            for off in [.75,2.25]: add(layer['drums'],tom,base+off,pan=-.36,gain=.19)
        if bar%4==3:
            for off,v in [(3.25,.15),(3.5,.21),(3.75,.3)]: add(layer['drums'],s,base+off,pan=-.13,gain=v)
        # Composed bass rhythms, unique to each environment.
        for off,interval in c['bass']:
            dur=.28 if id in ['city','canyon'] else .36
            kind='motor' if id in ['canyon','city','alien'] else 'bass'
            gain=.28 if id!='canyon' else .32
            add(layer['bass'],voice(root+interval,dur,kind),base+off,gain=gain*(.82 if interval else 1))
        if bar%2==0:
            for j,note in enumerate(ch):
                add(layer['pad'],voice(note,8*beat+.34,'pad',.037 if id!='snow' else .05),base,gain=1)
        # Harmonic rhythm and instrument layout differ substantially per course.
        if id=='coast':
            for off in [.5,1.75,2.5,3.5]:
                for j,note in enumerate(ch):
                    add(layer['arp'],voice(note,.31,'mallet',.053),base+off+j*.013,pan=(j-1.5)*.11)
        elif id=='snow':
            for step in range(16):
                degree=c['arp'][(step+bar*3)%16]
                note=ch[degree]+(24 if step in [3,11] else 12)
                add(layer['arp'],voice(note,.73,'glass',.070 if step%2 else .093),base+step*.25,pan=np.sin(step*.8+bar)*.55)
        elif id=='alien':
            for step,off in enumerate([0,.75,1.5,2.5,3.25]):
                note=ch[c['arp'][(step+bar)%8]]+(12 if alt and step==3 else 0)
                add(layer['arp'],voice(note,.54,'dark',.16),base+off,pan=(-.22 if step%2 else .24))
            if bar%2==0:
                add(layer['texture'],voice(root+12,8*beat+.2,'pad',.06),base,gain=.5)
        elif id=='canyon':
            for step,off in enumerate([.25,1,1.75,2.5,3.25]):
                note=ch[c['arp'][(step+bar)%8]]
                add(layer['arp'],voice(note,.38,'wood',.13),base+off,pan=np.sin(step*1.3)*.35)
        else:
            for step in range(8):
                note=ch[c['arp'][(step+(bar%2)*3)%8]]+12
                add(layer['arp'],voice(note,.46,'pluck' if id=='valley' else 'analog',.09 if id=='valley' else .055),base+step*.5,pan=np.sin((bar*8+step)*.72)*.32)
        # Two-bar call/response hooks are fully scored, with a changed second-half answer.
        melody=c['motif'][ci]
        if bar%2==0:
            for j,(off,note) in enumerate(zip(c['rhythm'],melody)):
                dur={'city':.82,'snow':.92,'alien':.72}.get(id,.58)
                gain={'valley':.16,'canyon':.145,'coast':.16,'snow':.102,'city':.12,'alien':.13}[id]
                add(layer['lead'],voice(note,dur,c['kind'],gain),base+off,pan=.08*np.sin(j))
        else:
            answer=[melody[-1],melody[0] if alt else melody[min(1,len(melody)-1)]]
            if id=='coast': answer=[melody[-1],melody[1],melody[0]]
            for j,note in enumerate(answer):
                off=1+j*.75 if id!='city' else .75+j*1.75
                add(layer['lead'],voice(note,.8,c['kind'],.115 if id!='snow' else .084),base+off,pan=-.14)
        if bar in [7,15]:
            tt=np.arange(round(beat*1.15*SR))/SR
            air=low(high(rng.standard_normal(len(tt)),500),2300)
            en=(tt/tt[-1])**2*np.minimum(1,(tt[-1]-tt)/.04)
            add(layer['texture'],air*en*.026,base+2.85,pan=-.16)
    # Periodic, click-free sidechain with short anticipation before the kick.
    phase=((np.arange(n)*64/n)%1)*beat
    amount=.56 if id in ['valley','coast','alien'] else .39
    duck=1-amount*np.exp(-phase/.085)
    pre=phase>beat-.007; w=(phase[pre]-(beat-.007))/.007; blend=.5-.5*np.cos(np.pi*w)
    duck[pre]=duck[pre]*(1-blend)+(1-amount)*blend
    for name in ['bass','pad','arp','lead','texture']: layer[name]*=duck[:,None]
    # Delays and room responses are cyclic, including the final phrase's tails.
    for name,wet in [('arp',.20 if id!='snow' else .30),('lead',.23),('pad',.19),('drums',.018)]:
        dry=layer[name].copy()
        for delay,amp in [(beat*.75,.58),(beat*1.5,.28),(beat*2.25,.13)]:
            layer[name]+=np.roll(dry,round(delay*SR),axis=0)[:,::-1]*(wet*amp)
        soft=circular_filter(dry,3200)
        for delay,amp in [(.031,.048),(.057,.04),(.091,.029),(.139,.021),(.203,.017)]:
            layer[name]+=np.roll(soft,round(delay*SR),axis=0)[:,::-1]*amp
    mix=sum(layer.values()).astype(np.float64)
    mix-=np.mean(mix,axis=0)
    mix=np.tanh(mix*1.10)
    mix*=10**(TARGET_RMS/20)/np.sqrt(np.mean(mix*mix))
    if np.max(np.abs(mix))>10**(-1.7/20):
        mix=np.tanh(mix/.6)*.6
        mix*=10**(TARGET_RMS/20)/np.sqrt(np.mean(mix*mix))
    if np.max(np.abs(mix))>10**(-1.5/20): mix*=10**(-1.5/20)/np.max(np.abs(mix))
    return mix,beat

def main():
    stats={}
    for c in CONFIGS:
        mix,beat=render(c)
        name='music-'+c['id']; wav=OUT/(name+'.wav'); mp3=OUT/(name+'.mp3')
        wavfile.write(wav,SR,np.rint(mix*32767).astype(np.int16))
        subprocess.run(['ffmpeg','-y','-v','error','-i',str(wav),'-c:a','libmp3lame','-b:a','160k','-write_xing','1',str(mp3)],check=True)
        raw=subprocess.run(['ffmpeg','-v','error','-i',str(mp3),'-f','f32le','-acodec','pcm_f32le','-'],stdout=subprocess.PIPE,check=True).stdout
        dec=np.frombuffer(raw,np.float32).reshape(-1,2)
        tp=20*np.log10(float(np.max(np.abs(resample_poly(dec,4,1,axis=0)))))
        row={k:c[k] for k in ['id','name','title','bpm','key','style','progression']}
        row.update(bars=BARS,beats=BARS*4,sample_rate=SR,channels=2,duration_seconds=len(mix)/SR,
                   wav_peak_dbfs=float(20*np.log10(np.max(np.abs(mix)))),wav_rms_dbfs=float(20*np.log10(np.sqrt(np.mean(mix**2)))),
                   decoded_peak_dbfs=float(20*np.log10(np.max(np.abs(dec)))),decoded_true_peak_dbfs_4x=float(tp),
                   decoded_rms_dbfs=float(20*np.log10(np.sqrt(np.mean(dec**2)))),loop_samples=len(mix),decoded_samples=len(dec),
                   decoded_boundary_step=float(np.max(np.abs(dec[0]-dec[-1]))),wav_boundary_step=float(np.max(np.abs(mix[0]-mix[-1]))),
                   interior_99_percentile_step=float(np.percentile(np.abs(np.diff(mix,axis=0)),99)),
                   first_20ms_rms_dbfs=float(20*np.log10(np.sqrt(np.mean(mix[:960]**2)))),
                   last_20ms_rms_dbfs=float(20*np.log10(np.sqrt(np.mean(mix[-960:]**2)))),
                   stereo_correlation=float(np.corrcoef(mix.T)[0,1]),mp3_bytes=mp3.stat().st_size,
                   mp3=str(mp3),wav=str(wav))
        assert len(mix)==len(dec), 'Gapless sample count mismatch'
        assert tp<=-1, 'Encoded peak exceeds headroom'
        assert -17<=row['decoded_rms_dbfs']<=-14, 'Loudness outside match range'
        assert row['wav_boundary_step']<.03, 'Unexpected loop boundary discontinuity'
        stats[c['id']]=row
        (OUT/'music-manifest.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2))
        print(json.dumps({k:row[k] for k in ['id','duration_seconds','decoded_rms_dbfs','decoded_true_peak_dbfs_4x','wav_boundary_step','mp3_bytes']},ensure_ascii=False),flush=True)
    return stats

if __name__=='__main__': main()
