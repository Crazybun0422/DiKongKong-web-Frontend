"""Original score and SFX, synthesized specifically for Drone Racing.
No source samples, third-party compositions, or vocals are used.
32 bars at 136 BPM. Circular scheduling and wrapped room tails preserve looping.
"""
from pathlib import Path
import json, subprocess
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile

OUT=Path(__file__).resolve().parent
SR=44100
BPM=136
BEAT=60/BPM
BARS=32
N=round(BARS*4*BEAT*SR)
DURATION=N/SR
rng=np.random.default_rng(230927)

def filt(x, hz, typ='lowpass', order=2):
    return sosfilt(butter(order,hz,typ,fs=SR,output='sos'),x,axis=0)
def midi(m): return 440*2**((m-69)/12)
def env(t,a,d,r=None):
    # Smooth attack, exponential release.
    v=(1-np.exp(-t/max(a,.0001)))*np.exp(-t/max(d,.0001))
    if r is not None: v*=np.minimum(1,np.maximum(0,(t[-1]-t)/r))
    return v

def add(track,x,seconds,pan=0,gain=1):
    start=round(seconds*SR)
    idx=(start+np.arange(len(x)))%N
    if x.ndim==1:
        p=(pan+1)*np.pi/4
        track[idx,0]+=x*(np.cos(p)*gain)
        track[idx,1]+=x*(np.sin(p)*gain)
    else: track[idx]+=gain*x

def synth(note,duration,kind='pluck',vel=1,phase=0):
    t=np.arange(round(duration*SR))/SR; f=midi(note)
    if kind=='pluck':
        # Soft rounded pulse/sine hybrid, with a descending spectral envelope.
        e=env(t,.006,.16 if duration<.5 else .25,.04)
        wave=np.sin(2*np.pi*f*t+phase)
        for h in [2,3,4,5,7]:
            wave+=.28/h*np.sin(2*np.pi*f*h*t+phase)*np.exp(-t*6)
        return wave*e*vel
    if kind=='bass':
        wave=.85*np.sin(2*np.pi*f*t)+.22*np.sin(4*np.pi*f*t)+.1*np.sin(6*np.pi*f*t)
        return wave*env(t,.004,.29,.028)*vel
    if kind=='lead':
        bend=1+.0015*np.sin(2*np.pi*5.2*t)
        phase=2*np.pi*f*np.cumsum(bend)/SR
        wave=np.sin(phase)+.2*np.sin(phase*2)+.06*np.sin(phase*3)
        return wave*env(t,.012,.3,.06)*vel
    if kind=='pad':
        # Detuned lower harmonics rather than a bright digital saw.
        ph=2*np.pi*f*t
        wave=np.zeros((len(t),2))
        for c,det in enumerate([.9978,1.0022]):
            wave[:,c]=np.sin(ph*det)+.28*np.sin(ph*2*det)+.1*np.sin(ph*3*det)
        attack=np.minimum(1,t/.23)
        release=np.minimum(1,np.maximum(0,(duration-t)/.46))
        return wave*(attack*release*vel)[:,None]

def kick():
    t=np.arange(round(.46*SR))/SR
    f=49+115*np.exp(-t/0.014)+24*np.exp(-t/.04)
    ph=2*np.pi*np.cumsum(f)/SR
    sig=np.sin(ph)*np.exp(-t/.105)*(1-np.exp(-t/.001))
    click=filt(rng.standard_normal(len(t)),2400)*np.exp(-t/.005)*.09
    return (sig+click)*np.minimum(1,np.maximum(0,(.46-t)/.04))
def snare():
    t=np.arange(round(.24*SR))/SR
    noise=filt(filt(rng.standard_normal(len(t)),900,'highpass'),6300)
    body=np.sin(2*np.pi*185*t)*np.exp(-t/.04)*.24
    clap=np.zeros(len(t))
    for ofs,amp in [(0,.7),(.013,.5),(.026,.8)]:
        j=round(ofs*SR)
        clap[j:]+=noise[:len(t)-j]*np.exp(-t[:len(t)-j]/.051)*amp
    return (clap*.38+body)*(1-np.exp(-t/.0008))*np.minimum(1,(t[-1]-t)/.03)
def hat(open_=False):
    dur=.23 if open_ else .075
    t=np.arange(round(dur*SR))/SR
    noise=filt(rng.standard_normal(len(t)),6500,'highpass')
    noise=filt(noise,11800)
    decay=.066 if open_ else .017
    return noise*env(t,.0008,decay,.02)*.26

tracks={k:np.zeros((N,2),dtype=np.float64) for k in ['drums','bass','arp','pad','lead','fx']}
k=kick()
s=snare()
h=hat(); oh=hat(True)
# Chords: E minor add9, C maj 7, G major 9, D sus2/major, each lasting two bars.
chords=[([52,55,59,66],28),([48,52,55,59],24),([47,50,55,57],31),([50,54,57,64],26)]
# 2-bar original arpeggio pitches are chord-relative (no sampled melody).
arp_order=[0,2,1,3,2,1,3,2, 0,1,2,3,1,2,3,1]
for bar in range(BARS):
    sec=bar*4*BEAT
    chord,root=chords[(bar//2)%4]
    section=bar//8
    for b in range(4):
        # A small turnaround breath at the end of each phrase, without a fade.
        if not (bar in (15,31) and b==3): add(tracks['drums'],k,sec+b*BEAT,gain=.92)
    for b in (1,3):
        add(tracks['drums'],s,sec+b*BEAT+.004,gain=.6 if section==0 else .69,pan=.025)
    for step in range(8):
        vel=.6 if step%2==0 else 1.0
        add(tracks['drums'],h,sec+step*.5*BEAT,pan=(-.24 if step%2==0 else .22),gain=vel*.62)
        if step%2 and not (bar==15 and step==7):
            add(tracks['drums'],oh,sec+step*.5*BEAT,pan=.3,gain=.25 if section==0 else .37)
    if section in (1,3):
        for step in (3,7,11,14,15):
            add(tracks['drums'],h,sec+step*.25*BEAT,pan=-.35,gain=.23 if step%2 else .4)
    if bar%8==7:
        for step,gv in [(13,.15),(14,.23),(15,.32)]:
            add(tracks['drums'],s,sec+step*.25*BEAT,pan=-.15,gain=gv)
    # Syncopated octave movement gives the low end forward momentum.
    for off,note,v in [(0,root,.83),(.75,root,.57),(1.5,root,.76),(2,root,.84),(2.75,root+12,.44),(3.5,root,.72)]:
        add(tracks['bass'],synth(note,.38,'bass',v),sec+off*BEAT,gain=.49)
    # Upper chord voicing; sustained with gentle stereo spread.
    if bar%2==0:
        for j,note in enumerate(chord):
            add(tracks['pad'],synth(note,8*BEAT+.25,'pad',.058),sec,gain=1)
    for st in range(8):
        order=arp_order[(bar%2)*8+st]
        note=chord[order]+12
        if section==2 and st in (2,6): note-=12
        velocity=.14 if st%2==0 else .115
        if section==0: velocity*=.82
        pan=np.sin((bar*8+st)*.78)*.34
        add(tracks['arp'],synth(note,.58,'pluck',velocity),sec+st*.5*BEAT,pan=pan)
    # Leave space in the first phrase; then introduce a composed, singing hook.
    if section in (1,3):
        motifs=[[(0,76,1.0),(1.5,74,.7),(2.5,71,.85),(3.25,67,.65)],
                [(.5,72,.75),(1.75,71,.62),(3,67,.9)],
                [(0,71,.9),(1.5,74,.68),(2.5,79,.72),(3.25,74,.65)],
                [(.5,78,.66),(1.75,76,.74),(3,74,.88)]]
        # Hook uses E, D, B, G / C B G / B D G D / F# E D.
        if bar%2==0:
            for off,note,vel in motifs[(bar//2)%4]:
                add(tracks['lead'],synth(note,.75,'lead',vel*.095),sec+off*BEAT,pan=.08)
        else:
            note=[71,67,74,69][(bar//2)%4]
            add(tracks['lead'],synth(note,1.15,'lead',.061),sec+2.5*BEAT,pan=-.12)
    # Tiny reverse-air pickup at each 8-bar turnaround.
    if bar%8==7:
        t=np.arange(round(1.25*BEAT*SR))/SR
        air=filt(filt(rng.standard_normal(len(t)),600,'highpass'),2600)
        swell=(t/(t[-1]+1/SR))**2*np.minimum(1,(t[-1]-t)/.025)
        add(tracks['fx'],air*swell*.042,sec+2.75*BEAT,pan=-.05)

# Gentle four-on-the-floor ducking, exactly periodic over all 128 beats.
time=np.arange(N)/SR
phase=((np.arange(N)*128/N)%1)*BEAT
sidechain=1-.74*np.exp(-phase/.091)
# Anticipate each kick with a 7 ms cosine ramp so the pumping envelope is continuous.
pre=phase>BEAT-.007
w=(phase[pre]-(BEAT-.007))/.007
sidechain[pre]=sidechain[pre]*(.5+.5*np.cos(np.pi*w))+.26*(.5-.5*np.cos(np.pi*w))
for layer in ['bass','pad','arp','lead']:
    tracks[layer]*=sidechain[:,None]

# Wrapped delay and room taps: the final tails arrive at the start of the loop.
for name,wet in [('arp',.2),('lead',.25),('pad',.2),('drums',.018)]:
    dry=tracks[name].copy()
    for delay,amp in [(BEAT*.75,.6),(BEAT*1.5,.30),(BEAT*2.25,.16)]:
        echo=np.roll(dry,round(delay*SR),axis=0)[:,::-1]
        tracks[name]+=echo*(wet*amp)
    # Broad soft stereo early reflections, using circular shifts to avoid cut tails.
    softened=filt(dry,3200)
    for j,(delay,amp) in enumerate([(.031,.10),(.053,.085),(.089,.067),(.137,.05),(.191,.04)]):
        echo=np.roll(softened,round(delay*SR),axis=0)
        if j%2: echo=echo[:,::-1]
        tracks[name]+=echo*amp

mix=sum(tracks.values())
# Block DC without adding a time-boundary artifact.
mix-=np.mean(mix,axis=0)
# Smooth saturation lifts quiet harmonics, while final peak stays below -1 dBFS.
mix=np.tanh(mix*1.2)
mix*=10**(-1.5/20)/np.max(np.abs(mix))

stats={}
def save(name,x):
    if x.ndim==1: x=np.column_stack([x,x])
    x=x-np.mean(x,axis=0)
    # SFX follow the same ceiling but don't force all effects to equal loudness.
    peak=np.max(np.abs(x))
    if peak>10**(-1.5/20): x*=10**(-1.5/20)/peak
    wav=OUT/(name+'.wav'); mp3=OUT/(name+'.mp3')
    wavfile.write(wav,SR,(np.clip(x,-1,1)*32767).astype(np.int16))
    subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(wav),'-c:a','libmp3lame','-b:a','160k','-write_xing','1',str(mp3)],check=True)
    stats[name]={'duration_seconds':round(len(x)/SR,6),'peak_dbfs':round(20*np.log10(np.max(np.abs(x))),3),'rms_dbfs':round(20*np.log10(np.sqrt(np.mean(x*x))),3),'mp3_bytes':mp3.stat().st_size}

save('music-race',mix)
# Original UI / race effects; all envelopes reach zero before their file end.
def stereo_spread(x,delay=.002):
    return np.column_stack([x,np.roll(x,round(delay*SR))])
# A warm ascending two-note gate flourish with an airy pass-by.
t=np.arange(round(.35*SR))/SR
pitch=720+560*(1-np.exp(-t/.065))
chirp=np.sin(2*np.pi*np.cumsum(pitch)/SR)*env(t,.003,.065,.04)
shine=np.sin(2*np.pi*1760*t)*env(np.maximum(0,t-.075),.004,.035,.025)*(t>.075)
air=filt(rng.standard_normal(len(t)),2200)*env(t,.008,.07,.035)
save('gate-pass',stereo_spread(chirp*.39+shine*.1+air*.065))
# Rounded low countdown note.
t=np.arange(round(.2*SR))/SR
count=(np.sin(2*np.pi*660*t)+.14*np.sin(2*np.pi*1320*t))*env(t,.004,.06,.04)*.46
save('countdown',count)
# Launch: rising motor bloom and bright E/B fifth, with finite smooth tail.
t=np.arange(round(.55*SR))/SR
f=145+560*(1-np.exp(-t/.13))
w=np.sin(2*np.pi*np.cumsum(f)/SR)+.2*np.sin(2*np.pi*np.cumsum(f*2)/SR)
noise=filt(rng.standard_normal(len(t)),2300)*.22
save('launch',stereo_spread((w+noise)*env(t,.017,.15,.12)*.4,.003))
# Crash: short low impact, controlled broadband rattle, no loud piercing transient.
t=np.arange(round(.6*SR))/SR
f=34+80*np.exp(-t/.031)
impact=np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t/.115)
rattle=filt(rng.standard_normal(len(t)),2300)*np.exp(-t/.095)*.6
crash=(impact+rattle)*(1-np.exp(-t/.0015))*np.minimum(1,(t[-1]-t)/.09)*.56
save('crash',stereo_spread(crash,.004))
# Finish: original E minor 9 rising figure ending on E, with short room bloom.
t=np.arange(round(1.2*SR))/SR
finish=np.zeros((len(t),2))
for i,(note,start) in enumerate([(64,0),(67,.12),(71,.24),(78,.36),(76,.50)]):
    sig=synth(note,min(.69,1.2-start),'pluck',.27 if i==4 else .21)
    at=round(start*SR); count=min(len(sig),len(t)-at)
    finish[at:at+count,0]+=sig[:count]*(.88 if i%2 else 1)
    finish[at:at+count,1]+=sig[:count]*(1 if i%2 else .88)
finish*=np.minimum(1,(t[-1]-t)/.12)[:,None]
save('finish',finish)
stats['composition']={'bpm':BPM,'bars':BARS,'beats':128,'key':'E minor','progression':'Em(add9) – Cmaj7 – Gadd9 – Dadd9, two bars each','sample_rate':SR,'loop_samples':N,'loop_boundary_max_step':float(np.max(np.abs(mix[0]-mix[-1]))),'original':True,'source_audio':'none; all instruments and effects synthesized'}
(OUT/'audio-manifest.json').write_text(json.dumps(stats,indent=2))
print(json.dumps(stats,indent=2))
