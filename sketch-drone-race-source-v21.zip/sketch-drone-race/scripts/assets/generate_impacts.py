"""Original material-impact sound design. No samples, recordings or third-party sources.
Deterministic offline synthesis using noise excitation, nonlinear crunch,
inharmonic resonators, and individually scattered debris events.
"""
from pathlib import Path
import json, subprocess, sys
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt, resample_poly

OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parents[2]/'public'/'audio'
OUT.mkdir(parents=True,exist_ok=True)
SR=48000
RNG=np.random.default_rng(917031)

def band(x,lo,hi):
    if lo is None: sos=butter(2,hi,fs=SR,output='sos')
    elif hi is None: sos=butter(2,lo,'highpass',fs=SR,output='sos')
    else: sos=butter(2,[lo,hi],'bandpass',fs=SR,output='sos')
    y=sosfilt(sos,x)
    return y/(np.std(y)+1e-9)
def attack(t,ms=.45): return 1-np.exp(-t/(ms/1000))
def endenv(t,span): return np.minimum(1,np.maximum(0,(t[-1]-t)/span))
def noise(n,lo,hi): return band(RNG.standard_normal(n),lo,hi)
def stereo(x,pan=0):
    theta=(pan+1)*np.pi/4
    return np.column_stack([x*np.cos(theta),x*np.sin(theta)])
def put(dst,x,when,pan=0,amp=1):
    i=round(when*SR); n=min(len(x),len(dst)-i)
    if n>0: dst[i:i+n]+=stereo(x[:n],pan)*amp

def modal(t,freqs,decays,weights,phase=False):
    result=np.zeros(len(t))
    for f,d,w in zip(freqs,decays,weights):
        ph=RNG.uniform(0,2*np.pi) if phase else 0
        result+=np.sin(2*np.pi*f*t+ph)*np.exp(-t/d)*w
    return result

def impact(kind,duration):
    n=round(duration*SR); t=np.arange(n)/SR
    out=np.zeros((n,2)); a=attack(t,.30)
    # Instantaneous hard contact: noise with a 14ms burst and dry upper crack.
    crack=(noise(n,1800,10500)*.90*np.exp(-t/.013)
           +noise(n,550,4700)*.52*np.exp(-t/.027))*a
    out+=stereo(crack)*1.1
    # Driven low-mid mass, several broad resonances, not a pure sine beep.
    punch=(noise(n,90,310)*.48*np.exp(-t/.098)
         +modal(t,[117,161,209,287],[.100,.092,.078,.050],[.73,.50,.41,.17]))
    punch=np.tanh(punch*1.35)*np.exp(-t/.27)*a
    out+=stereo(punch)*1.10
    # Body drops quickly into the sub range; grit masks the tonal component.
    f=44+53*np.exp(-t/.048)
    phase=2*np.pi*np.cumsum(f)/SR
    sub=np.sin(phase)*np.exp(-t/.115)*a
    out+=stereo(sub)*.76
    # Sustained tearing body: multiple nonlinearly driven noisy material bands.
    hold=np.where(t<.085,1.,np.exp(-(t-.085)/(.105 if kind!='gate' else .085)))
    riplo=np.tanh(noise(n,180,1500)*1.4)
    ripmid=np.tanh(noise(n,1000,4700)*1.1)
    riphi=np.tanh(noise(n,3300,10300)*.7)
    rough=.79+.21*np.sin(2*np.pi*(67*t+22*t*t))**2
    core=(riplo*.51+ripmid*.44+riphi*.17)*hold*rough*a
    out+=stereo(core)*1.05
    # Extra independent side energy widens fracture texture while the punch stays centered.
    side=noise(n,900,6500)*hold*a*.075
    out[:,0]+=side; out[:,1]-=side
    # A causal sequence of cracking pieces, dense for the first quarter second.
    count={'obstacle':11,'gate':8,'ground':7}[kind]
    for j in range(count):
        at=.023+j*.022+RNG.uniform(-.005,.007)
        length=.09+RNG.uniform(0,.045); tt=np.arange(round(length*SR))/SR
        coarse=noise(len(tt),250,3800)
        fracture=np.tanh(coarse*2.0)*attack(tt,.15)*np.exp(-tt/(.016+RNG.uniform(0,.013)))*endenv(tt,.012)
        put(out,fracture,at,RNG.uniform(-.34,.34),.18+.22*np.exp(-j/8))
    if kind=='obstacle':
        # Chunky plastic/carbon shell crush and a second structural collapse.
        grain=np.tanh(noise(n,320,2400)*2.0)
        irr=.45+.55*(np.sin(2*np.pi*43*t)*np.sin(2*np.pi*71*t)>-.1)
        out+=stereo(grain*irr*np.exp(-t/.175)*a)*.36
        tt=np.arange(round(.22*SR))/SR
        thud=(noise(len(tt),85,560)*.5+np.sin(2*np.pi*137*tt)*.35)*attack(tt,.5)*np.exp(-tt/.05)*endenv(tt,.025)
        put(out,thud,.108,-.08,.43)
        modes=[490,833,1297,2189,3179]
        decay=[.09,.10,.08,.07,.06]
    elif kind=='gate':
        # Bent metal has inharmonic modes and beating pairs, excited by the crack.
        modes=[346,551,887,1339,2083,3217,4841]
        decay=[.29,.34,.39,.26,.22,.16,.12]
        clang=modal(t,modes,decay,[.13,.18,.17,.19,.15,.12,.08])
        clang+=modal(t,[x*1.009 for x in modes],decay,[.05,.06,.06,.07,.05,.04,.02])
        out+=stereo(clang*a)*.53
        # Contact rattles against the frame twice after the main strike.
        for at,level,p in [(.23,.20,-.25),(.37,.14,.33)]:
            tt=np.arange(round(.38*SR))/SR
            rattle=modal(tt,[427,963,1561,2763],[.05,.07,.08,.05],[.3,.4,.26,.20])
            rattle+=noise(len(tt),1500,7400)*np.exp(-tt/.013)*.25
            put(out,rattle*attack(tt,.18)*endenv(tt,.04),at,p,level)
    else:
        # Ground hit: a dry mid-heavy scrape with irregular friction and grit.
        modes=[382,719,1133,1687,2477]
        decay=[.07,.09,.08,.08,.06]
        start=.09
        u=np.maximum(t-start,0)
        scrape_env=attack(u,5)*np.exp(-u/.26)*(t>=start)
        scrape_env*=.37+.63*(.5+.5*np.sin(2*np.pi*(25*u+19*u*u)))
        scrape=noise(n,410,6200)*scrape_env
        out+=stereo(scrape,-.15)*.23
        # Two secondary ground thumps from the body tumbling.
        for at,level in [(.20,.27),(.405,.13)]:
            tt=np.arange(round(.19*SR))/SR
            thump=(noise(len(tt),70,750)*.55+np.sin(2*np.pi*159*tt)*.21)
            put(out,thump*attack(tt,.35)*np.exp(-tt/.043)*endenv(tt,.025),at,.13,level)
    # Debris: discrete bright fragments, different timing and spectrum per material.
    num={'obstacle':16,'gate':15,'ground':19}[kind]
    at=.095
    for j in range(num):
        at+=RNG.uniform(.024,.078)*(1+.028*j)
        if at>duration-.23: break
        length=.16+RNG.uniform(0,.19); tt=np.arange(round(length*SR))/SR
        base=RNG.uniform(950,2850)
        if kind=='gate':
            freqs=[base,base*1.437,base*2.163]
            ds=[.055,.036,.027]
            frag=modal(tt,freqs,ds,[.43,.22,.1])
            frag+=noise(len(tt),1800,10000)*np.exp(-tt/.004)*.38
        else:
            freqs=[base,base*1.719,base*2.297]
            ds=[.012,.009,.006]
            frag=modal(tt,freqs,ds,[.32,.19,.11])
            frag+=noise(len(tt),1200,9300)*np.exp(-tt/.008)*.5
        frag*=attack(tt,.1)*endenv(tt,.025)
        level=(.13+.14*RNG.random())*np.exp(-at/.83)
        put(out,frag,at,RNG.uniform(-.75,.75),level)
    # A short dark acoustic bloom gives mass without washing out the initial crack.
    dry=out.copy()
    for delay,level in [(.019,.047),(.037,.032),(.061,.020)]:
        idx=round(delay*SR)
        softened=np.column_stack([sosfilt(butter(1,3200,fs=SR,output='sos'),dry[:,c]) for c in (1,0)])
        out[idx:]+=softened[:-idx]*level
    out*=endenv(t,.12)[:,None]
    # Remove very low DC energy before nonlinear mastering.
    hp=butter(2,24,'highpass',fs=SR,output='sos')
    out=sosfilt(hp,out,axis=0)
    # Drive the whole event smoothly until the first 200ms reaches intended density.
    # This changes transient crest and material crunch, not merely output gain.
    target=-8.2
    best=None
    for drive in np.linspace(.6,6.5,120):
        mastered=np.tanh(out*drive)
        mastered*=10**(-1.35/20)/np.max(np.abs(mastered))
        mastered-=np.mean(mastered,axis=0)
        mastered*=endenv(t,.06)[:,None]
        peak=np.max(np.abs(mastered))
        if peak>10**(-1.35/20): mastered*=10**(-1.35/20)/peak
        rms=20*np.log10(np.sqrt(np.mean(mastered[:round(.2*SR)]**2)))
        delta=abs(rms-target)
        if best is None or delta<best[0]: best=(delta,mastered.copy(),float(drive))
    return best[1],best[2]

def encode(name,x,mp3_gain=1):
    wav=OUT/f'{name}.wav'; mp3=OUT/f'{name}.mp3'
    wavfile.write(wav,SR,np.rint(x*32767).astype(np.int16))
    # MP3 gets its own encoding headroom; preserve the intended WAV transient peak.
    pcm=np.asarray(x*mp3_gain,dtype=np.float32).tobytes()
    subprocess.run(['ffmpeg','-y','-v','error','-f','f32le','-ar',str(SR),'-ac','2','-i','pipe:0','-c:a','libmp3lame','-b:a','192k','-write_xing','1',str(mp3)],input=pcm,check=True)
    raw=subprocess.run(['ffmpeg','-v','error','-i',str(mp3),'-f','f32le','-acodec','pcm_f32le','-'],stdout=subprocess.PIPE,check=True).stdout
    return np.frombuffer(raw,np.float32).reshape(-1,2)

stats={}
for kind,dur in [('obstacle',1.65),('gate',1.85),('ground',1.70)]:
    name='impact-'+kind
    x,drive=impact(kind,dur)
    decoded=encode(name,x)
    # Iteratively protect against lossy-encoding and intersample overshoot.
    mp3_gain=1.
    for _ in range(5):
        tp=float(np.max(np.abs(resample_poly(decoded,4,1,axis=0))))
        tp_db=20*np.log10(tp)
        if -1.28 <= tp_db <= -1.04: break
        mp3_gain*=10**(-1.18/20)/tp
        decoded=encode(name,x,mp3_gain)
    first=x[:round(.2*SR)]
    stats[name]={
        'duration_seconds':len(x)/SR,'sample_rate':SR,'channels':2,
        'wav_peak_dbfs':float(20*np.log10(np.max(np.abs(x)))),
        'first_200ms_rms_dbfs':float(20*np.log10(np.sqrt(np.mean(first**2)))),
        'first_3ms_peak_dbfs':float(20*np.log10(np.max(np.abs(x[:round(.003*SR)])))),
        'first_200ms_crest_db':float(20*np.log10(np.max(np.abs(first))/np.sqrt(np.mean(first**2)))),
        'decoded_first_200ms_rms_dbfs':float(20*np.log10(np.sqrt(np.mean(decoded[:round(.2*SR)]**2)))),
        'mp3_encode_gain_db':float(20*np.log10(mp3_gain)),
        'decoded_mp3_peak_dbfs':float(20*np.log10(np.max(np.abs(decoded)))),
        'decoded_4x_true_peak_dbfs':float(20*np.log10(np.max(np.abs(resample_poly(decoded,4,1,axis=0))))),
        'dc_mean':np.mean(x,axis=0).tolist(),
        'first_sample_abs':float(np.max(np.abs(x[0]))),
        'final_sample_abs':float(np.max(np.abs(x[-1]))),
        'decoded_samples':len(decoded),'wav_samples':len(x),
        'mp3_bytes':(OUT/f'{name}.mp3').stat().st_size,
        'nonlinear_master_drive':drive,
        'source':'Original deterministic synthesis; no recorded/sample/API audio'
    }
(OUT/'impact-stats.json').write_text(json.dumps(stats,indent=2))
print(json.dumps(stats,indent=2))
