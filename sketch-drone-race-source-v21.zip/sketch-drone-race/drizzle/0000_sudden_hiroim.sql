CREATE TABLE `race_players` (
	`id` text PRIMARY KEY NOT NULL,
	`token` text NOT NULL,
	`room_code` text NOT NULL,
	`name` text NOT NULL,
	`drone` text NOT NULL,
	`state` text NOT NULL,
	`steer` integer DEFAULT 0 NOT NULL,
	`boost` integer DEFAULT 0 NOT NULL,
	`updated_at` integer NOT NULL,
	`finish_ms` integer,
	FOREIGN KEY (`room_code`) REFERENCES `race_rooms`(`code`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `idx_players_room` ON `race_players` (`room_code`);--> statement-breakpoint
CREATE TABLE `race_rooms` (
	`code` text PRIMARY KEY NOT NULL,
	`host_id` text NOT NULL,
	`status` text DEFAULT 'waiting' NOT NULL,
	`start_at` integer,
	`created_at` integer NOT NULL
);
