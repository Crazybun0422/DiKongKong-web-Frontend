import DroneLab from "./drone-lab";
export default function Home() { return <DroneLab />; }
