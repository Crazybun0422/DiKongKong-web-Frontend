import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "涂鸦飞行社 · 画出来，飞起来",
  description: "随手绘制无人机，生成立体机体，和好友一起竞速。",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
