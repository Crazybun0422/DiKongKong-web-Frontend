# 涂鸦飞行社

可玩的手绘无人机竞赛原型。使用 Canvas 绘制、WebGL 深度缓冲和软件逐像素深度后备渲染，Vinext / React 提供界面，Cloudflare D1 保存好友房间与比赛状态。

## 玩法

1. 用鼠标或触屏绘制俯视草图，也可选择示例。
2. 点击生成：闭合圆圈识别为旋翼，同心圈识别涵道，中央闭合轮廓生成机身，机臂连接至旋翼。没有明确圆圈时按轮廓推测支点并补全。
3. 选择单人试飞，或创建 2–6 人好友房间。
4. 自动前进，方向键 / A、D 转向，空格冲刺；触屏有独立操作按钮。
5. 选择山谷、峡谷、海岸、雪岭或夜城；穿过发光圆环补充能量，碰到橙色障碍减速，完成 2400 米航道。

## 边界

- 图形启发式识别与参数化模型生成，没有调用生成式 AI 或外部付费模型。
- 模型保留旋翼位置和机身轮廓，并做适合小游戏的造型规整；不保证解释任意复杂抽象图画。
- 好友赛通过 HTTP 轮询同步，服务器计算进度与完成时间。它是可玩原型，尚未采用 WebSocket / 专用实时游戏服务器。
- Sites 默认只允许所有者访问。邀请其他人前，应由所有者明确开放站点访问。
- 临时房间有效期 1 小时；本轮身份保留在页面内，刷新后需重新加入。没有账号和全球排行榜。

## 开发

采用项目已有 pnpm 锁文件。`pnpm dev` 启动开发，`pnpm build` 构建。管理环境通过 Sites 脚本构建和发布。

D1 逻辑绑定为 DB。定义在 db/schema.ts，SQL 迁移在 drizzle/。创建数据库后按顺序应用迁移。生产发布由 Sites 自动管理绑定和迁移。

核心文件：app/drone-lab.tsx（交互）、lib/drone.ts（识别与飞行模拟）、lib/render.ts（三维机体和赛道）、app/api/race/route.ts（好友房间与服务器比赛计算）。

## 验证

已验证 TypeScript 类型和生产构建；三种不同机型可以通过飞行模拟到达终点。浏览器检查覆盖生成、试飞、房间创建与加入。WebMCP 运行时未在当前预览浏览器提供，注册采用能力检测，不影响正常游戏。

## 第二版造型修复

提供四旋、三旋、H 型、竞速、六旋、八旋、涵道四旋、双涵道、纵列双旋、复合翼共 10 类结构模板。

lib/mesh.ts 构造带顶底和侧壁的实体网格，机臂在旋翼平面下方连接电机立柱。lib/drone-renderer.ts 使用逐像素深度测试，避免按面平均深度排序导致遮挡错乱。WebGL 不可用时使用同样的网格做软件深度缓冲。

生成后检查完整旋翼包络到机身、机翼及其他旋翼的距离。保留简单凹轮廓，复杂自交笔画规整为可建模轮廓。10 个模板分类与旋翼间隙已通过数值核验。

## 第三版：精细机体与 128 款机库

- `lib/airframes.ts` 定义 16 个现实结构系列，每系列 8 个原创配置，共 128 款。它们改变机身长宽、旋翼间距、桨径、叶数、电池装配及飞行响应，并非现实品牌型号或厂家性能复刻。机库支持分类、搜索与每页 16 款。
- 机壳分段放样、壳体接缝、铰链、圆管臂、电机外转子/定子细节、扭转桨叶、镜筒与云台、传感器、电池绑带、GNSS 与 FPV 天线、起落架、植保药箱及货箱分别建模。固定翼有翼型和尾翼；X8/Y6 使用上下共轴旋翼；直升机含主桨、尾梁和侧向尾桨。
- 预览支持双轴拖动、缩放、暂停旋翼。WebGL 使用逐片元光照、材质高光和深度测试；软件后备包含深度和表面光照。
- 所有飞行共用曲线航线与高度函数。左右控制带速度和阻尼，姿态包含横滚、俯仰与航向，自动跟随高度；附全程小地图。属于游戏飞行动力学，不是六自由度空气动力学模拟器。
- `catalogId` 经服务端查表，用同一个构造函数重建机型，不接受客户端自报性能。原有房间与排名继续使用服务端计算。
- 128 款构造、顶点有限性、旋翼平面间隙、机型往返重建、轻微画稿修改、飞行完赛和惯性数值检查均已通过。浏览器检查覆盖细节预览、分类选型、复合翼生成和实际试飞。

## 第四版：空间赛道与冲刺

- 五个场景共用 `lib/courses.ts` 的权威航线、高度和圆环尺寸，各有独立弯道、坡度、地形及建筑。
- `lib/race-world.ts` 将机体、道路、立体金属环、支架、光晕与障碍放进同一深度测试场景；环保持到摄像机穿过后离开画面。无 WebGL 时使用缓存机体图像的 Canvas 后备赛道。
- 穿环采用跨平面位置插值与圆形孔径检测，计入机体包络，避免大步长漏判和矩形判定；穿过后闪光并补能，漏环分别计数。
- 冲刺上限为巡航的 1.72 倍，响应加快；蓝白短喷流、加速视野和画面边缘速度线同步出现。已移除机体后方持续航迹线；轻点产生 0.55 秒短冲刺，按住持续冲刺。
- 缩略图进入视野后逐帧构建，暂停预览复用画面，绘图缓冲区稳定复用，前方地形在空闲时间预构建。好友赛按服务器时间外推并平滑画面，房主场景为房间统一设置。
- 五个场景已验证中心穿环、边缘拒绝、只计一次和完赛。默认机型巡航约 78 km/h，冲刺 0.6 秒约 130 km/h。当前云端浏览器不提供 WebGL，页面操作与后备画面在浏览器检查，GPU 着色器另做编译检查；帧率仍取决于设备。

## 第五版：高速飞行与轻量气流

- 默认航拍机游戏巡航从 78 提高到约 168 km/h；冲刺倍率 2.1，约 0.6 秒达到 350 km/h。所有机型使用同一套服务端/客户端速度公式，机库同步显示竞速巡航。
- 低位近距离跟随镜头替代高位远镜头；WebGL 与 Canvas 共用 60–71 度动态视角，实际速度决定扩张程度。
- 完全删除两种渲染路径中的机尾喷流。仅用细、短、半透明的白灰气流描绘空气掠过，频率按真实行进距离变化。
- 加入路肩反光桩和路面短标线；Canvas 道路色块改为绑定世界坐标，防止换段时花纹跳动。
- 提速后同步调整横向响应及高度斜率跟随，保留跨平面插值穿环和 12 ms 模拟子步。

## 第六版：恢复速度参数，修正视觉速度

- 撤回第五版巡航加 90 km/h 和 2.1 倍冲刺，恢复各机型原始巡航与 1.72 倍冲刺；恢复原加速、转向响应。默认机型约 78 / 134 km/h。
- 跟随镜头改为后方 14 m、上方 2.8 m，冲刺随真实速度轻微前移并拓宽视野；两种渲染路径共用设置。
- 路缘反光桩和短标线加密至 5–6 m；坐标固定在真实赛道上，与光环、碰撞、里程共用同一行进距离，不给背景额外速度倍率。
- 空气线按近处三维粒子投影，长度由真实速度和 22 ms 曝光时间决定；细、淡、无发光、无机尾连接，中央穿环区域留空。

## 第七版：强化狂飙视感

- 保持第六版物理速度、加速度、操控、赛程及穿环规则原样，仅修改相机与画面。
- 追逐镜头降到机体上方 1.7 m，后距 12.5 m；冲刺随实际速度前推并由 62 度平滑拓宽至 78 度。
- 调整现有景物分布，让更多树木、岩石、建筑在路边近处掠过，总数不增加。
- 使用可复用的半分辨率画面，做一次外围径向模糊合成，中央保留清晰；在小地图和穿环提示之前绘制。
- 增强近处空气的光流密度，按实际行进距离运动，限制线长及透明度，继续无喷流和机尾拖线。

## 第八版：清晰的快速掠过

- 删除第七版的外围画面副本、径向模糊和重影合成，恢复每帧单次清晰画面。
- 相对于玩家的纵向显示比例固定为 2.6，让物体临近时的纵向位移更快；不改巡航、冲刺、操控、计时或赛程逻辑。
- 赛道按连续顶点映射，机体、光环、障碍和树木建筑只映射中心，保持自身比例。两种渲染路径共用比例，物理穿环点仍与画面中心平面重合。
- 固定追逐视野，避免冲刺时镜头拉远抵消前进速度感；保留少量细气流，取消额外画面拷贝。
- 装饰赛道块按显示距离等距生成，路面标线与景物的经过频率约提高到原来的 2.6 倍；每个可见块的景物数量保持不变，避免只拉远远景或增加逐帧绘制量。

## Flight challenge update
- Arrow keys / WASD steer horizontally and climb or descend; touch controls support simultaneous axes and boost. Releasing climb holds the chosen height relative to the terrain.
- Gates use four aperture sizes and a deterministic high/low flight path shared by both renderers and server physics.
- Six obstacle sequences alternate low walls, overhead beams, side gaps and high/low windows at 180 m intervals.
- First solid contact with an obstacle, ring frame/support or ground immediately crashes the aircraft. Swept collisions use the displayed world depth and stop at first contact. Crashes end the attempt without an eligible finish time in solo or multiplayer.
- Clear misses remain missed gates; glow never collides. Existing speed display and clear, unblurred 2.6x optical travel are preserved.

## Smooth aircraft surfaces
- Rounded fuselage profiles, smooth per-vertex normals for shell/arms/motors, rolled duct rims and curved airfoil wings preserve each family’s construction.
- Beveled camera housings and battery lids replace sharp block edges. No changes to rotor placement, flight parameters or collisions.
- Software rendering interpolates vertex lighting, supersamples silhouettes and reuses its raster buffers. Preview canvases support 2x pixel density, and race fallback aircraft use 512 px cached sprites.
- Removed the unfiltered carbon weave that produced shimmering patterns during rotation.

## Boost rotor response and chase camera
- Restored the original 19 rad/s preview and 24 rad/s cruising propeller rates. Race boost eases to 72 rad/s over 0.18 s and returns over 0.22 s; angle is integrated continuously and freezes at impact.
- Software race rendering now animates only the blade meshes over a cached body/depth layer, with the same boost response.
- Both race renderers share an aircraft-centered chase camera: lateral movement, climb, descent and banking keep the body origin centered; course curvature no longer pulls the look-at point away. Existing flight speeds, field of view and optical travel scale are preserved.
