import { integer, sqliteTable, text, index } from "drizzle-orm/sqlite-core";
export const rooms = sqliteTable("race_rooms", {
 code: text("code").primaryKey(), hostId: text("host_id").notNull(), status: text("status").notNull().default("waiting"), startAt: integer("start_at"), createdAt: integer("created_at").notNull()
});
export const players = sqliteTable("race_players", {
 id: text("id").primaryKey(), token: text("token").notNull(), roomCode: text("room_code").notNull().references(()=>rooms.code,{onDelete:"cascade"}), name: text("name").notNull(), drone: text("drone").notNull(), state: text("state").notNull(), steer: integer("steer").notNull().default(0), boost: integer("boost").notNull().default(0), updatedAt: integer("updated_at").notNull(), finishMs: integer("finish_ms")
}, t=>[index("idx_players_room").on(t.roomCode)]);
