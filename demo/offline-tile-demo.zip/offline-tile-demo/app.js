﻿(function () {
  'use strict'

  var DEFAULT_CENTER = { lat: 39.908823, lng: 116.39747 }
  var DEFAULT_ZOOM = 11
  var EMPTY_TILE_DATA_URL = 'data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs='

  if (!window.OfflineTileApi) {
    throw new Error('OfflineTileApi not loaded')
  }

  var OfflineTilePackage = window.OfflineTileApi.OfflineTilePackage

  var state = {
    map: null,
    pack: null,
    clickMarker: null,
    offlineMapType: null,
    offlineMapTypeIndex: -1,
    zoomPrepareToken: 0,
  }

  var $ = {
    fileInput: document.getElementById('zipFile'),
    loadBtn: document.getElementById('loadBtn'),
    clearBtn: document.getElementById('clearBtn'),
    summary: document.getElementById('packSummary'),
    clickResult: document.getElementById('clickResult'),
    zoomInfo: document.getElementById('zoomInfo'),
    coordType: document.getElementById('coordType'),
  }

  function setSummary(text) {
    $.summary.textContent = text
  }

  function setClickResult(text) {
    $.clickResult.textContent = text
  }

  function getCurrentZoom() {
    if (!state.map || typeof state.map.getZoom !== 'function') {
      return DEFAULT_ZOOM
    }
    return Math.round(state.map.getZoom())
  }

  function setOfflineLayerVisible(visible) {
    if (!state.map || !window.qq || !window.qq.maps) {
      return
    }

    if (!visible || !state.offlineMapType) {
      if (state.offlineMapTypeIndex > -1) {
        state.map.overlayMapTypes.removeAt(state.offlineMapTypeIndex)
        state.offlineMapTypeIndex = -1
      }
      return
    }

    if (state.offlineMapTypeIndex === -1) {
      state.offlineMapTypeIndex = state.map.overlayMapTypes.push(state.offlineMapType) - 1
    }
  }

  function refreshOfflineLayer() {
    if (!state.map || !state.offlineMapType) {
      return
    }
    setOfflineLayerVisible(false)
    setOfflineLayerVisible(true)
  }

  function ensureOfflineMapType() {
    if (state.offlineMapType || !window.qq || !window.qq.maps || !window.qq.maps.ImageMapType || !window.qq.maps.Size) {
      return state.offlineMapType
    }

    state.offlineMapType = new window.qq.maps.ImageMapType({
      name: 'OfflineTiles',
      tileSize: new window.qq.maps.Size(256, 256),
      isPng: true,
      getTileUrl: function (tileCoord, zoom) {
        if (!state.pack) return EMPTY_TILE_DATA_URL
        var z = Number(zoom)
        var x = Number(tileCoord && tileCoord.x)
        var y = Number(tileCoord && tileCoord.y)
        var url = state.pack.getTileObjectUrlSync(z, x, y)
        return url || EMPTY_TILE_DATA_URL
      },
    })

    return state.offlineMapType
  }

  async function prepareZoomTiles(zoom, token, silent) {
    if (!state.pack) {
      return
    }

    var z = Number(zoom)
    if (!Number.isFinite(z)) {
      return
    }

    if (!state.pack.hasZoom(z)) {
      if (!silent) {
        setSummary('当前缩放 Z' + z + ' 无离线瓦片，图层为空白')
      }
      refreshOfflineLayer()
      return
    }

    var availableZooms = state.pack.getAvailableZooms()
    for (var i = 0; i < availableZooms.length; i += 1) {
      var otherZoom = Number(availableZooms[i])
      if (otherZoom !== z && state.pack.isZoomPrepared(otherZoom)) {
        state.pack.releaseZoomTileUrls(otherZoom)
      }
    }

    var stats = await state.pack.prepareZoomTileUrls(z)
    if (token !== state.zoomPrepareToken) {
      return
    }

    if (!silent) {
      setSummary('已加载瓦片包 | Z' + z + ' 已准备 ' + stats.prepared + '/' + stats.total + ' 张瓦片')
    }

    refreshOfflineLayer()
  }

  function initMap() {
    if (!window.qq || !window.qq.maps) {
      throw new Error('qq.maps not loaded')
    }

    state.map = new window.qq.maps.Map(document.getElementById('map'), {
      center: new window.qq.maps.LatLng(DEFAULT_CENTER.lat, DEFAULT_CENTER.lng),
      zoom: DEFAULT_ZOOM,
      mapTypeControl: false,
    })

    ensureOfflineMapType()

    window.qq.maps.event.addListener(state.map, 'zoom_changed', function () {
      var z = getCurrentZoom()
      $.zoomInfo.textContent = '当前缩放：Z' + z

      if (!state.pack) return
      state.zoomPrepareToken += 1
      var token = state.zoomPrepareToken
      prepareZoomTiles(z, token, true).catch(function (error) {
        if (token !== state.zoomPrepareToken) return
        setSummary('缩放瓦片准备失败：' + ((error && error.message) || error))
      })
    })

    window.qq.maps.event.addListener(state.map, 'click', async function (event) {
      var lat = Number(event && event.latLng && event.latLng.getLat && event.latLng.getLat())
      var lng = Number(event && event.latLng && event.latLng.getLng && event.latLng.getLng())
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
        return
      }

      renderClickMarker(lat, lng)
      var zoom = getCurrentZoom()

      if (!state.pack) {
        setClickResult('未加载（点击坐标：' + lat.toFixed(6) + ', ' + lng.toFixed(6) + '）')
        return
      }

      try {
        var result = await state.pack.classifyPoint({
          lng: lng,
          lat: lat,
          zoom: zoom,
          coordType: ($.coordType && $.coordType.value) || 'GCJ02',
        })

        if (!result.loaded) {
          setClickResult('未加载：' + result.reason + ' | Z' + result.z + '/' + result.x + '/' + result.y)
          return
        }

        setClickResult(
          result.zone + ' | ' + result.detail + ' | Z' + result.z + '/' + result.x + '/' + result.y +
          ' | RGBA(' + result.rgba.r + ',' + result.rgba.g + ',' + result.rgba.b + ',' + result.rgba.a + ')'
        )
      } catch (error) {
        setClickResult('识别失败：' + ((error && error.message) || error))
      }
    })

    $.zoomInfo.textContent = '当前缩放：Z' + DEFAULT_ZOOM
  }

  function renderClickMarker(lat, lng) {
    if (!state.map || !window.qq || !window.qq.maps) {
      return
    }

    if (state.clickMarker) {
      try {
        state.clickMarker.setMap(null)
      } catch (e) {
        // ignore
      }
      state.clickMarker = null
    }

    state.clickMarker = new window.qq.maps.Marker({
      map: state.map,
      position: new window.qq.maps.LatLng(lat, lng),
    })
  }

  function fitToBounds(bounds) {
    if (!state.map || !window.qq || !window.qq.maps || !bounds) {
      return
    }

    var sw = bounds.southwest || bounds
    var ne = bounds.northeast || bounds
    var swLat = Number((sw && sw.latitude) || bounds.minLat)
    var swLng = Number((sw && sw.longitude) || bounds.minLng)
    var neLat = Number((ne && ne.latitude) || bounds.maxLat)
    var neLng = Number((ne && ne.longitude) || bounds.maxLng)

    if (![swLat, swLng, neLat, neLng].every(Number.isFinite)) {
      return
    }

    try {
      var qqBounds = new window.qq.maps.LatLngBounds(
        new window.qq.maps.LatLng(swLat, swLng),
        new window.qq.maps.LatLng(neLat, neLng)
      )
      state.map.fitBounds(qqBounds)
    } catch (e) {
      // ignore
    }
  }

  async function onLoadPack() {
    var file = $.fileInput && $.fileInput.files && $.fileInput.files[0]
    if (!file) {
      setSummary('请先选择 zip 文件')
      return
    }

    setSummary('正在加载离线瓦片包...')
    setClickResult('未加载')

    try {
      if (state.pack) {
        state.pack.dispose()
      }

      var pack = await OfflineTilePackage.fromFile(file)
      state.pack = pack
      state.zoomPrepareToken += 1
      var token = state.zoomPrepareToken

      var summary = pack.getLoadedSummary()
      var zoomText = summary.availableZooms.length
        ? summary.availableZooms.join(',')
        : '无'

      setSummary('已加载瓦片包 | 可用缩放: [' + zoomText + '] | downloaded=' + summary.downloaded)

      setOfflineLayerVisible(true)
      fitToBounds(pack.metadata && pack.metadata.bounds ? pack.metadata.bounds : null)
      await prepareZoomTiles(getCurrentZoom(), token, false)
      setClickResult('已加载，点击地图识别区域')
    } catch (error) {
      if (state.pack) {
        state.pack.dispose()
      }
      state.pack = null
      setOfflineLayerVisible(false)
      setSummary('加载失败：' + ((error && error.message) || error))
      setClickResult('未加载')
    }
  }

  function onClearPack() {
    if (state.pack) {
      state.pack.dispose()
    }
    state.pack = null
    state.zoomPrepareToken += 1

    setOfflineLayerVisible(false)
    setSummary('未加载')
    setClickResult('未加载')
  }

  function bindEvents() {
    $.loadBtn.addEventListener('click', onLoadPack)
    $.clearBtn.addEventListener('click', onClearPack)
  }

  function bootstrap() {
    initMap()
    bindEvents()
    setSummary('未加载')
    setClickResult('未加载')
  }

  bootstrap()
})()
